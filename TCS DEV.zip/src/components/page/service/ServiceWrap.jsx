import React from "react";
import ClientTestimonial from "./ClientTestimonial";
import PriceCardWrap from "./PriceCardWrap";
import ServiceCardWrap from "./ServiceCardWrap";

function ServiceWrap() {
  return (
    <>
      <ServiceCardWrap />
      <ClientTestimonial />
      <PriceCardWrap />
    </>
  );
}

export default ServiceWrap;
